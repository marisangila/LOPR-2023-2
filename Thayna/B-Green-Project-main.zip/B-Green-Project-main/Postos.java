public class Postos {
    public String rua;
    public String numero;
    public String cidade;
}
