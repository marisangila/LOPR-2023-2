public class Evento {
    public String nome;
    public String data;
    public String endereco;
    public String organizador;
}
